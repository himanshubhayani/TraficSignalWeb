import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';

import { AdminService } from './admin.service';
import { AdminComponent } from './admin.component';
import { MatSliderModule } from '@angular/material/slider';
import { SharedModule } from '../shared/shared.module';
const routes: Routes = [
    {
        path: '',
        component: AdminComponent
    }
];

@NgModule({
    declarations: [
        AdminComponent
    ],
    imports: [
        SharedModule,
        RouterModule.forChild(routes),
    ],
    exports: [
        RouterModule
    ],
    providers: [
        AdminService
    ]
})
export class AdminModule {
}

