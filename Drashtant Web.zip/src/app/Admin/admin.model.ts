export class Post {
    PostId:number;
    Title: Array<string>=['','',''];
    ShortDescription: Array<string>=['','',''];
    FullDescription: Array<string>=['','',''];
    TagList: string='';
    Published:boolean=false;
}
export class Tags {
    TagId: number;
    TagName: string;
}
export class PostSearch {
    Title: string;
    LanguageId = 1;
    StartDate: string;
    EndDate: string;
    PageSize :number;
    PageNum :number;
    OrderColumnName: string;
    OrderColumnDir: string;
}