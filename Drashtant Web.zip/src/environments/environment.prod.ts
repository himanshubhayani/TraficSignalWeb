export const environment = {
  api_URL: 'http://api.drashtant.co/api/',
  production: true
};
