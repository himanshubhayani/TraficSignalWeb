import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { CommonService } from 'src/app/commonService/common.service';
import { HeaderService } from './header.service';
import { EventEmitterService } from 'src/app/commonService/event-emiter.service';
@Component({
  selector: 'app-header',
  templateUrl: './header.component.html',
  styleUrls: ['./header.component.css']
})
export class HeaderComponent implements OnInit {
  language: number;
  constructor(
    private router: Router,
    private commonService: CommonService,
    private headerService: HeaderService, private eventEmitterService: EventEmitterService) { }

  ngOnInit() {
  }
  SelectedLanguage(event) {
    localStorage.setItem('language', event);
    window.location.reload();
    // this.eventEmitterService.changeLanguage();
  }
}

