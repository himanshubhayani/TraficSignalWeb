import { Injectable } from '@angular/core';
import { environment } from 'src/environments/environment';
import { HttpService } from 'src/app/commonService/http-service';
@Injectable()
export class HomeService {

  baseURL: string = environment.api_URL;

  constructor(private httpService: HttpService) { }
  GetAllPost(data) {
    return this.httpService.post('Home/GetAllPost', data);
  }
  getAllTagsByLanguage(data) {
    return this.httpService.post('Home/GetAllTagsByLanguage', data);
  }
  getAllPhrase(data) {
    return this.httpService.post('Home/getAllPhrase', data);
  }
  getReadingPost(data) {
    return this.httpService.post('Home/GetReadingPost', data);
  }
  getUserDetails(data) {
    return this.httpService.post('UserDetails/GetUserDetails', data);
  }
}
