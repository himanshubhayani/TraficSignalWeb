import { Component, OnInit, ChangeDetectorRef } from '@angular/core';
import { AdminService } from './admin.service';
import { Post, Tags, PostSearch } from './admin.model';
import { HttpErrorResponse } from '@angular/common/http';
@Component({
    selector: 'admin',
    templateUrl: './admin.component.html',
    styleUrls: ['./admin.component.scss']
})
export class AdminComponent implements OnInit {
    isLoader = false;
    length: number = 0;
    pageNo: number = 1;
    titleArray: string[] = [];
    newPost: Post = new Post();
    tagList = new Array<Tags>();
    postFilter = new PostSearch();
    CkeConfig = {
        toolbar: [
            { name: 'mode', items: ['Source'] },
            { name: 'basicstyles', items: ['Bold', 'Italic', 'Underline', 'Subscript', 'Superscript'] },
            { name: 'styles', items: ['Format', 'Styles', 'Font'] },
            { name: 'paragraph', items: ['JustifyLeft', 'JustifyCenter', 'JustifyRight', 'JustifyBlock'] },
            { name: 'colors', items: ['TextColor', 'BGColor'] },
        ],
    };
    displayedColumns: string[] = ['Action', 'Title', 'Created Date'];
    dataSource: any;
    createPostBool: boolean;
    english: boolean = true;
    hindi: boolean;
    gujrati: boolean;
    saveDisable: boolean;
    constructor(
        private adminService: AdminService, private cdr: ChangeDetectorRef) {
    };

    ngOnInit() {
        this.getAllTags();
        this.getPost();
    }

    getAllTags() {
        this.adminService.GetAllTags().subscribe((response: any) => {
            if (response.Success) this.tagList = response.Model;
        }, (err: HttpErrorResponse) => {
        });
    }
    getPost() {
        const language = localStorage.getItem('language');
        if (language == '1') this.postFilter.LanguageId = 1;
        if (language == '2') this.postFilter.LanguageId = 2;
        if (language == '3') this.postFilter.LanguageId = 3;
        this.adminService.GetAllPost(this.postFilter).subscribe((response: any) => {
            if (response.Success) {
                this.dataSource = response.Model;
                if (this.dataSource.length != 0) {
                    this.length = this.dataSource[0].TotalRecords / 3;
                }
            }
        }, (err: HttpErrorResponse) => {
        });
    }
    receiveDateRange(event: any) {
        this.postFilter.StartDate = event.startDate;
        this.postFilter.EndDate = event.endDate;
        this.postFilter.PageNum = 1;
        this.getPost();
    }
    search(event) {
        const wordSearch = event.target.value;
        setTimeout(() => {
            if (wordSearch === event.target.value) {
                this.postFilter.PageNum = 1;
                this.pageNo = this.postFilter.PageNum;
                this.getPost();
            }
        }, 1000);
    }

    onPaste(event: ClipboardEvent) {
        setTimeout(() => {
            this.getPost();
        }, 1000);
    }
    createPost() {
        this.createPostBool = true;
        this.newPost = new Post();
    }
    EnglishGrid() {
        this.english = true;
        this.hindi = false;
        this.gujrati = false;
    }
    HindiGrid() {
        this.english = false;
        this.hindi = true;
        this.gujrati = false;
    }
    GujratiGrid() {
        this.english = false;
        this.hindi = false;
        this.gujrati = true;
    }
    editPost(event) {
        this.adminService.GetPostById(event).subscribe((response: any) => {
            if (response.Success) {
                this.createPostBool = true;
                if (response.Model[0].Published) this.newPost.Published = true;
                else this.newPost.Published = false;
                this.newPost.PostId = response.Model[0].PostId;
                this.newPost.Title[0] = response.Model[0].Title;
                this.newPost.Title[1] = response.Model[1].Title;
                this.newPost.Title[2] = response.Model[2].Title;
                this.newPost.ShortDescription[0] = response.Model[0].ShortDescription;
                this.newPost.ShortDescription[1] = response.Model[1].ShortDescription;
                this.newPost.ShortDescription[2] = response.Model[2].ShortDescription;
                this.newPost.FullDescription[0] = response.Model[0].FullDescription;
                this.newPost.FullDescription[1] = response.Model[1].FullDescription;
                this.newPost.FullDescription[2] = response.Model[2].FullDescription;
            }
        }, (err: HttpErrorResponse) => {
        });
    }

    deletePost(event) {
        this.adminService.DeletePost(event).subscribe((response: any) => {
            if (response.Success) {
                this.getPost();
            }
        }, (err: HttpErrorResponse) => {
        });

    }
    backToGrid() {
        this.createPostBool = false;
    }
    multiSelection(event) {
        this.titleArray;
        if (event.length >= 0) {
            this.newPost.TagList = event.join(",");
        }
    }
    save() {
        if (this.newPost.Title[0] == '' || this.newPost.Title[1] == '' || this.newPost.Title[2] == '' ||
            this.newPost.ShortDescription[0] == '' || this.newPost.ShortDescription[1] == '' || this.newPost.ShortDescription[2] == '' ||
            this.newPost.FullDescription[0] == '' || this.newPost.FullDescription[1] == '' || this.newPost.FullDescription[2] == '' || this.newPost.TagList == '') {
            this.saveDisable = true;
        } else {
            this.saveDisable = false;
            this.adminService.CreatePost(this.newPost).subscribe((response: any) => {
                if (response) {
                    this.createPostBool = false;
                    this.getPost();
                    this.newPost = new Post();
                }
            }, (err: HttpErrorResponse) => {
            });
        }

    }
    receiveFromPagination(event: any) {
        this.postFilter.PageSize = event.pageSize * 3;
        this.postFilter.PageNum = event.pageIndex + 1;
        this.getPost();
    }
}