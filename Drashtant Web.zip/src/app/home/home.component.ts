import { Component, OnInit, ChangeDetectorRef, HostListener } from '@angular/core';
import { Router, ActivatedRoute } from '@angular/router';
import { CommonService } from 'src/app/commonService/common.service';
import { HttpErrorResponse } from '@angular/common/http';
import { HomeService } from './home.service';
import { postFilter, PostList, Phrase, phraseEnum, ContinuePost, ReadingPost, PopularPost, UserDetails } from './home.model';
import { AdminService } from '../Admin/admin.service';
import { Tags } from '../Admin/admin.model';
import { EventEmitterService } from '../commonService/event-emiter.service';
@Component({
  selector: 'home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {
  continueReading: boolean;
  isLoader = false;
  length: number = 0;
  pageNo: number = 1;
  postFilter = new postFilter();
  phrase = new phraseEnum();
  continuePost = new ContinuePost();
  selectedTag: number;
  selectedPost: number;
  tagList = new Array<Tags>();
  allTagList;
  postList = new Array<PostList>();
  readingPost = new Array<ReadingPost>();
  popularPost = new Array<PopularPost>();
  recentPost = new Array<PopularPost>();
  recentPostId: any;
  readingPostId;
  userDetails = new UserDetails();
  splitTagText = [];
  topButton: boolean;
  constructor(
    private router: Router, private activatedRoute: ActivatedRoute,
    private commonService: CommonService,
    private homeService: HomeService, private adminService: AdminService, private eventEmitterService: EventEmitterService) { }

  ngOnInit() {
    this.selectedTag = +localStorage.getItem('TagId');
    if (this.activatedRoute.snapshot.params.id) this.postFilter.TagId = this.activatedRoute.snapshot.params.id;
    if (this.activatedRoute.snapshot.params.PostId) {
      this.continuePost.PostId = this.activatedRoute.snapshot.params.PostId;
      this.continue(this.continuePost);
    }
    // if (this.eventEmitterService.subsVar == undefined) {
    //   this.eventEmitterService.subsVar = this.eventEmitterService.
    //     language.subscribe((name: string) => {
    //       this.getAllTagsByLanguage();
    //       this.getAllPost();
    //       this.getAllPhrase();
    //     });
    // }
    this.getAllTagsByLanguage();
    this.getAllPost();
    this.getAllPhrase();
  }
  @HostListener("window:scroll", ["$event"])
  onWindowScroll() {
    if(document.documentElement.scrollTop<100)this.topButton = false;
    else this.topButton = true;
    //In chrome and some browser scroll is given to body tag
    let pos = (document.documentElement.scrollTop || document.body.scrollTop) + document.documentElement.offsetHeight;
    let max = document.documentElement.scrollHeight - 500;
    // pos/max will give you the distance between scroll bottom and and bottom of screen in percentage.
    if (pos > max) {
      this.postFilter.PageNum = this.postFilter.PageNum + 1;
      this.getAllPost();
      //Do your action here
    }
  }
  TopScroll(){
    window.scroll(0,0);
  }
  clearTag() {
    localStorage.removeItem('TagId');
    window.location.reload();
  }

  getAllPhrase() {
    const language = localStorage.getItem('language');
    this.selectedPost = +localStorage.getItem('PostId');
    if (language == '1') this.postFilter.LanguageId = 1;
    if (language == '2') this.postFilter.LanguageId = 2;
    if (language == '3') this.postFilter.LanguageId = 3;

    this.homeService.getAllPhrase(this.postFilter.LanguageId).subscribe((response: any) => {
      if (response.Success) {
        this.phrase.popularPost = response.Model[9].Phrase;
        this.phrase.Tags = response.Model[10].Phrase;
        this.phrase.recentPost = response.Model[11].Phrase;
        this.phrase.randomPost = response.Model[12].Phrase;
        this.phrase.relatedPost = response.Model[13].Phrase;
        this.phrase.continueReading = response.Model[15].Phrase;
      }
    }, (err: HttpErrorResponse) => {
    });
  }
  getAllTagsByLanguage() {
    const language = localStorage.getItem('language');
    if (language == '1') this.postFilter.LanguageId = 1;
    if (language == '2') this.postFilter.LanguageId = 2;
    if (language == '3') this.postFilter.LanguageId = 3;
    this.homeService.getAllTagsByLanguage(this.postFilter.LanguageId).subscribe((response: any) => {
      if (response.Success) {
        this.tagList = response.Model;
        this.tagList = [...this.tagList];
        this.allTagList = response.Model1;
      }
    }, (err: HttpErrorResponse) => {
    });
  }
  SelectTag(event) {
    this.continueReading = false;
    this.postFilter.TagId = event.TagId;
    this.selectedTag = event.TagId;
    localStorage.setItem('TagId', event.TagId);
    this.router.navigate(['/home/AllTag/', event.TagId, event.TagText]);
    this.getAllPost();
  }

  getTag(event): boolean {
    this.splitTagText = event.TagText.split(", ");
    console.log(this.splitTagText);
    return true;
  }

  getAllPost() {
    this.isLoader = true;
    const language = localStorage.getItem('language');
    if (language == '1') this.postFilter.LanguageId = 1;
    if (language == '2') this.postFilter.LanguageId = 2;
    if (language == '3') this.postFilter.LanguageId = 3;
    //const userId = localStorage.getItem('userId');
    this.postFilter.TagId = +localStorage.getItem('TagId');
    //this.postFilter.UserId = JSON.parse(userId);
    const postId = +localStorage.getItem('PostId');
    this.postFilter.BrowserCodeName = navigator.appCodeName;
    this.postFilter.BrowserName = navigator.appName;
    this.postFilter.BrowserVersion = navigator.appVersion;
    this.postFilter.CookiesEnabled = navigator.cookieEnabled;
    this.postFilter.BrowserLanguage = navigator.language;
    this.postFilter.BrowserOnline = navigator.onLine;
    this.postFilter.Platform = navigator.platform;
    this.postFilter.Useragentheader = navigator.userAgent;
    this.postFilter.PostId = postId;
    //this.postFilter.UserID = JSON.parse(userId);
    this.homeService.GetAllPost(this.postFilter).subscribe((response: any) => {
      if (response) {
        response.Model.forEach(element => {
          this.postList.push(element);
        });
        this.popularPost = response.Model1;
        this.recentPost = response.Model2;
        if (response.Model.length != 0) this.length = response.Model[0].TotalRecords;
        else this.length = 0;
        this.isLoader = false;

      }
    }, (err: HttpErrorResponse) => {
    });
  }
  continue(event) {
    debugger
    if (event.PostId != this.selectedPost) {
      this.isLoader = true;
      this.postFilter.TagId = event.TagId;
      localStorage.setItem('PostId', event.PostId);
      this.selectedPost = +localStorage.getItem('PostId');
      this.router.navigate(['/home/Post/', event.PostId]);
      if (this.activatedRoute.snapshot.params.PostId) {
        const language = localStorage.getItem('language');
        if (language == '1') this.continuePost.LanguageId = 1;
        if (language == '2') this.continuePost.LanguageId = 2;
        if (language == '3') this.continuePost.LanguageId = 3;
        this.continuePost.PostId = event.PostId;
        // const userId = localStorage.getItem('userId');
        // this.continuePost.UserId = JSON.parse(userId);
        this.homeService.getReadingPost(this.continuePost).subscribe((response: any) => {
          if (response.Success) {
            this.continueReading = true;
            this.isLoader = false;
            this.readingPost = response.Model;
            this.readingPostId = this.readingPost["PostId"];
            this.getAllPost();
            this.postList = response.Model1;
            window.scroll(0, 0);
          }
        }, (err: HttpErrorResponse) => {
        });
      }
    }
  }
  search(event) {
    const wordSearch = event.target.value;
    setTimeout(() => {
      if (wordSearch === event.target.value) {
        this.pageNo = 1;
        this.getAllPost();
      }
    }, 1000);
  }
  receiveFromPagination(event: any) {
    this.postFilter.PageSize = event.pageSize;
    this.postFilter.PageNum = event.pageIndex + 1;
    this.getAllPost();
  }

  userData() {
    const postId = +localStorage.getItem('PostId');
    const userId = localStorage.getItem('userId');
    this.userDetails.BrowserCodeName = navigator.appCodeName;
    this.userDetails.BrowserName = navigator.appName;
    this.userDetails.BrowserVersion = navigator.appVersion;
    this.userDetails.CookiesEnabled = navigator.cookieEnabled;
    this.userDetails.BrowserLanguage = navigator.language;
    this.userDetails.BrowserOnline = navigator.onLine;
    this.userDetails.Platform = navigator.platform;
    this.userDetails.Useragentheader = navigator.userAgent;
    this.userDetails.PostId = postId;
    this.userDetails.UserId = JSON.parse(userId);
    this.homeService.getUserDetails(this.userDetails).subscribe(data => {

    })
  }

}

