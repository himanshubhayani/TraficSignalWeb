import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { AuthGuard } from './commonService/auth-guard.service';


const routes: Routes = [
  { path: '', redirectTo: 'home', pathMatch: 'full' },
  { path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: 'home/AllTag/:id/:text', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: 'home/Post/:PostId', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) },
  { path: 'login', loadChildren: () => import('./auth/login/login.module').then(m => m.LoginModule) },
  { path: 'admin', loadChildren: () => import('./Admin/admin.module').then(m => m.AdminModule), canActivate: [AuthGuard] },
  { path: '**', loadChildren: () => import('./home/home.module').then(m => m.HomeModule) }
]

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
