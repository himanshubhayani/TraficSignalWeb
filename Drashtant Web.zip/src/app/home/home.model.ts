
export class postFilter {
  Title: string;
  TagId: number;
  LanguageId: number = 1;
  PageSize=5;
  PageNum = 1;
  UserId: number;
  BrowserCodeName: string;
  BrowserName: string;
  BrowserVersion: string;
  CookiesEnabled: boolean;
  BrowserLanguage: string;
  BrowserOnline: boolean;
  Platform: string;
  Useragentheader: string;
  PostId: number;
  UserID: number;
}
export class GetAllPostDesc {
  Title: string;
  LanguageId: number = 1;
}
export class PostList {
  RowNum: number;
  TotalRecords: number;
  PostId: number;
  Title: string;
  ShortDescription: string;
  FullDescription: string;
  VisitedCount: number = 0;
  TagId: number;
}
export class Phrase {
  PhraseId: number;
  LanguageId: number;
  CodeName: string;
  Phrase: string = '';
  IsActive: boolean;
}
export class phraseEnum {
  Tags: string = '';
  continueReading: string;
  relatedPost: string;
  recentPost: string;
  randomPost: string;
  popularPost: string;
}
export class ReadingPost {
  PostId: number;
  Title: string;
  ShortDescription: string;
  FullDescription: string;
  VisitedCount: number = 0;
  TagId: number;
  TagText: string;
}
export class ContinuePost {
  PostId: number;
  LanguageId: number = 1;
  UserId: number;
}
export class PopularPost {
  PostId: number;
  Title: string;
  VisitedCount: number = 0;
}
export class UserDetails {
  BrowserCodeName: string;
  BrowserName: string;
  BrowserVersion: string;
  CookiesEnabled: boolean;
  BrowserLanguage: string;
  BrowserOnline: boolean;
  Platform: string;
  Useragentheader: string;
  PostId: number;
  UserId: number;
}


